﻿using System;
using ObjectOrientedPractics.Services;
using System.Text.RegularExpressions;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace ObjectOrientedPractics.Model
{
    /// <summary>
    /// Хранит данные о адресе.
    /// </summary>
    public class Address : ICloneable, IEquatable<Address>
    {
        /// <summary>
        /// Почтовый индекс.
        /// </summary>
        private int _index;

        /// <summary>
        /// Страна/регион.
        /// </summary>
        private string _country;

        /// <summary>
        /// Город (населенный пункт).
        /// </summary>
        private string _city;

        /// <summary>
        /// Улица.
        /// </summary>
        private string _street;

        /// <summary>
        /// Номер дома.
        /// </summary>
        private string _building;

        /// <summary>
        /// Номер квартиры/помещения.
        /// </summary>
        private string _apartment;

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>
        /// Возвращает и задает почтовый индекс. Должен быть шестизначным числом.
        /// </summary>
        public int Index
        {
            get => _index;
            set
            {
                Regex regex = new Regex(@"\b\d{6}\b");
                if (!regex.IsMatch(value.ToString()))
                {
                    throw new System.ArgumentException();
                }

                _index = value;
                OnPropertyChanged();

            }
        }

        /// <summary>
        /// Возвращает и задает страну/регион. Должен быть не более 50 символов.
        /// </summary>
        public string Country
        {
            get => _country;
            set
            {
                ValueValidator.AssertStringOnLength(value, 50, nameof(Country));
                _country = value;
                OnPropertyChanged();

            }
        }

        /// <summary>
        /// Возвращает и задает город (населенный пункт). Должен быть не более 50 символов.
        /// </summary>
        public string City
        {
            get => _city;
            set
            {
                ValueValidator.AssertStringOnLength(value, 50, nameof(City));
                _city = value;
                OnPropertyChanged();
            }
        }

        /// <summary>
        /// Возвращает и задает улицу. Должна быть не более 100 символов.
        /// </summary>
        public string Street
        {
            get => _street;
            set
            {
                ValueValidator.AssertStringOnLength(value, 100, nameof(Street));
                _street = value;
                OnPropertyChanged();
            }
        }

        /// <summary>
        /// Возвращает и задает номер дома. Должен быть не более 10 символов.
        /// </summary>
        public string Building
        {
            get => _building;
            set
            {
                ValueValidator.AssertStringOnLength(value, 10, nameof(Building));
                _building = value;
                OnPropertyChanged();
            }
        }

        /// <summary>
        /// Возвращает и задает номер квартиры/помещения. Должен быть не более 10 символов.
        /// </summary>
        public string Apartment
        {
            get => _apartment;
            set
            {
                ValueValidator.AssertStringOnLength(value, 10, nameof(Apartment));
                _apartment = value;
                OnPropertyChanged();
            }
        }

        /// <summary>
        /// Создают экземпляр класса <see cref="Address"/>.
        /// </summary>
        /// <param name="index">Почтовый индекс.</param>
        /// <param name="country">Страна/регион.</param>
        /// <param name="city">Город (населенный пункт).</param>
        /// <param name="street">Улица.</param>
        /// <param name="building">Номер дома.</param>
        /// <param name="apartament">Номер квартиры/помещения.</param>
        public Address(int index, string country, string city, string street, string building, string apartament)
        {
            Index = index;
            Country = country;
            City = city;
            Street = street;
            Building = building;
            Apartment = apartament;
        }

        /// <summary>
        /// Создают экземпляр класса <see cref="Address"/>.
        /// </summary>
        public Address() { }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public object Clone()
        {
            return new Address(this.Index, this.Country, this.City, this.Street, this.Building, this.Apartment);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="other"></param>
        /// <returns></returns>
        public bool Equals(Address other)
        {
            if (other == null) return false;

            return other.Street == this.Street &&
                   other.Apartment == this.Apartment &&
                   other.Building == this.Building &&
                   other.City == this.City &&
                   other.Country == this.Country &&
                   other.Index == this.Index;
        }
    }
}
