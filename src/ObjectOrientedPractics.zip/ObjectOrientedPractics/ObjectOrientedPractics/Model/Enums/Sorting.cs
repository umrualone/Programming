﻿namespace ObjectOrientedPractics.Model.Enums
{
    public enum Sorting
    {
        ID,

        Name,

        CostLess,

        CostGreater,
    }
}
